package com.medicine.model;

import javax.persistence.Column;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.FutureOrPresent;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

@Entity
@Table(name="medicine")

public class Medicine {
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="medid")
	private int id;
	@Column(name="medName")
	@NotNull(message = "medicine name cannot be empty")
	private String medName;
	//@PastOrPresent
	@Column(name="manfDate")
	private String manfDate;
	//@FutureOrPresent
	@Column(name="expDate")
	private String expDate;
	@Size(min = 10,max = 200, message = "description must be between 10 and 200 characters")
	@Column(name="description")
	private String description;
	@Positive
	@Column(name="price")
	private int price;
	@NotBlank(message="please mention the status")
	@Column(name="status")
	private String status;
	public Medicine(String medName, String manfDate, String expDate, String description, int price, String status) {
        super();
        this.medName = medName;
        this.manfDate = manfDate;
        this.expDate = expDate;
        this.description = description;
        this.price = price;
        this.status = status;
    }
	public Medicine() {
		// TODO Auto-generated constructor stub
	}

	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMedName() {
		return medName;
	}
	public void setMedName(String medName) {
		this.medName = medName;
	}
	public String getManfDate() {
		return manfDate;
	}
	public void setManfDate(String manfDate) {
		this.manfDate = manfDate;
	}
	public String getExpDate() {
		return expDate;
	}
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	


}
