package com.medicine.services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicine.model.U_Signup;
import com.medicine.repository.U_SignupRepository;


@Service
public class U_SignupService {

	@Autowired
	U_SignupRepository u_signupRepository;
	
	@Transactional
	public List<U_Signup> fetchusers() {
		List<U_Signup> userList=u_signupRepository.findAll();
		return userList;
		
	}
	@Transactional
	public U_Signup saveuser(U_Signup u_signup) {
		
		return u_signupRepository.save(u_signup);
		
	}
	@Transactional
	public void update(U_Signup u) {
		u_signupRepository.save(u);	
	
	}
	
	@Transactional
	public void deleteuser(int u_id) {
		
		System.out.println("service method called");
		u_signupRepository.deleteById(u_id);
	
	}
	@Transactional 
	  public U_Signup getuser(int u_id) { 
	  Optional<U_Signup> optional= u_signupRepository.findById(u_id);
	  U_Signup u=optional.get();
	  return u;
	  }
	
	public U_Signup validateUser(U_Signup user) {
		U_Signup u=u_signupRepository.validateUser(user.getu_id(),user.getpassword());
		
		return u;
	}
}
