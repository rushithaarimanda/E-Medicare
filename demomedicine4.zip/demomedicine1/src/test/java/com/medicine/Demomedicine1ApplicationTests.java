package com.medicine;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.medicine.model.U_Signup;
import com.medicine.repository.U_SignupRepository;

@SpringBootTest
class Demomedicine1ApplicationTests {

	@Test
	void contextLoads() {
	}
	@Autowired
	U_SignupRepository u_signupRepository;

	@Test
	
	public void addU_Signup() {
		U_Signup u_signup = new U_Signup();
		u_signup.setu_id(1);
		u_signup.setfirstname("Ankush");
		u_signup.setlastname("Pardeshi");
		u_signup.setcontact_no(9552);
		u_signup.setemail("ankush@gmail.com");
		u_signup.setpassword("Ankush@123");
		u_signup.setdob("08-06-1999");
		u_signup.setgender("male");
				
		assertNotNull(u_signupRepository.findById(1).get());
	}
	@Test
	public void AllU_Signup() {		
			List<U_Signup> list = u_signupRepository.findAll();
			assertThat(list).size().isGreaterThan(0);
		}

	@Test
	public void U_Signup() {
		U_Signup u_signup = u_signupRepository.findById(1).get();
		assertEquals(1, u_signup.getu_id());


}
	

}
